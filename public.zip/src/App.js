import React, { useEffect, useState } from 'react';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';

function App() {
  const [client, setClient] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  // const [nickname, setNickname] = useState('사용자1');

  useEffect(() => {
    const newClient = new Client({
      webSocketFactory: () => new SockJS('http://localhost:8080/ws'),
      // connectHeaders: {
      //   nickname: nickname,
      // },
      onConnect: () => {
        console.log('Connected');
        setIsConnected(true);
        newClient.subscribe('/topic/invitations', (message) => {
          // 수신된 메시지를 콘솔에 출력하거나 alert 창으로 표시
          console.log('Received message:', message.body);
          alert('알림: ' + message.body);
        });
        newClient.subscribe('/topic/alerts', (message) => {
          alert('알림: ' + message.body);
        });
      },
      onDisconnect: () => {
        console.log('Disconnected');
        setIsConnected(false);
      },
    });

    newClient.activate();
    setClient(newClient);

    return () => {
      newClient.deactivate();
    };
  }, []);

  const sendInvitation = () => {
    if (client && isConnected) {
      // 메시지 전송
      client.publish({
        destination: '/app/invite',
        body: '테스트 메시지',
      });
      console.log('Invitation sent');
    } else {
      console.log('WebSocket connection is not active');
    }
  };

  return (
    <div className="App">
      <h1>WebSocket Test</h1>
      <button onClick={sendInvitation} disabled={!isConnected}>전체 메세지 보내기</button>
    </div>
  );
}

export default App;
